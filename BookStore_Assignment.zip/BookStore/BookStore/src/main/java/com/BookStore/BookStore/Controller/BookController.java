package com.BookStore.BookStore.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.BookStore.BookStore.Entity.BookEntity;
import com.BookStore.BookStore.Service.BookService;


@RestController
public class BookController<BookStore> {
	@Autowired BookService service;
	
	@GetMapping ("/bookstore/books")
	public List <BookEntity> getAllBookStore()
	{
		return service.getAllBook();
	}
	
@PostMapping("/bookstore/books")
	public BookEntity insertBookStore(@RequestBody BookEntity b)
	{
		return service.addBookStore(b);
	}

@PutMapping("/bookstore/books/{id}")
public BookEntity updateBookStore (@PathVariable("id") Integer id, @RequestBody BookEntity b)
{
	return service.editBookStore(b, id);

}
@RequestMapping(method = RequestMethod.GET,path="/bookstore/books/{id}")
public BookEntity getBookStoreDetails(@PathVariable("id")Integer id) {
	return service.getBookStore(id);
}



@RequestMapping(method=RequestMethod.DELETE,path="/bookstore/books/{id}")
public String removeBookStore(@PathVariable("id")Integer id) {
	service.deleteBookStore(id);
	return "book details are removed successfully........";
}
}
	


