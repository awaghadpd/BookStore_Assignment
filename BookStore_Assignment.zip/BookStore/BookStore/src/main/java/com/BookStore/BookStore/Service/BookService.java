package com.BookStore.BookStore.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.BookStore.BookStore.Repository.BookRepository;
import com.BookStore.BookStore.Entity.BookEntity;



@Service
public class BookService {
	@Autowired BookRepository repo;

	public List<BookEntity> getAllBook() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	public BookEntity addBookStore(BookEntity b) {
		// TODO Auto-generated method stub
		return repo.save(b);
	}

	public BookEntity editBookStore(BookEntity b,Integer id) {
		// TODO Auto-generated method stub
		return repo.save(b);
	}

	public BookEntity getBookStore(Integer id) {
		// TODO Auto-generated method stub
		return repo.findById(id).get();
	}

	public void deleteBookStore(Integer id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);
	}
	
}


	


	


